//
//  ChoooseFace.swift
//  BookCore
//
//  Created by Sterben on 2021/4/18.
//

import Foundation
public enum FaceName {
    case red
    case blue
    case white
    case black
    case yellow
}

public func chooseFace(named: FaceName) -> (sceneName: String, text: String) {
    let sceneName: String
    let text: String
    switch named {
    case .red:
        sceneName = "red"
        text = "    Red face It symbolizes loyalty, uprightness, and blood, such as Guan Yu in \"Three Kingdoms Opera\" and Wu Han in \"Zhan jingtang\"."
    case .blue:
        sceneName = "blue"
        text = "    Blue facebook It is a symbol of fierceness, loyalty and resistance,such as Dou Erdun in \"Comic Set\" and the green-faced tiger in \"Baishuitan\""
    case .white:
        sceneName = "white"
        text = "    White mask Expressing treacherous and suspicious, derogatory meaning, representing fierce deceit, such as: Cao Cao in \"Three Kingdoms Opera\""
    case .black:
        sceneName = "black"
        text = "    Black facebook the performance is serious, unsmiling, neutral, representing Mengzhi. Such as Bao Zheng in \"Bao Gong Opera\""
    case .yellow:
        sceneName = "yellow"
        text = "    Yellow facebook It symbolizes the character of the military commander who is brave, cruel, fierce, fierce, insidious, and scheming."
    }
    
    return (sceneName, text)
}


