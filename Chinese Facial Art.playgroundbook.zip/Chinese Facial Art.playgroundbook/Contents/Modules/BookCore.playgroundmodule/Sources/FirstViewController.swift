//
//  FirstViewController.swift
//  BookCore
//
//  Created by Sterben on 2021/4/12.
//

import UIKit
import PlaygroundSupport
import PencilKit
import SceneKit
import ARKit

public var chooseFaceName = chooseFace(named: .red)
public var show3DText: Bool = true

@objc(BookCore_FirstViewController)
public class FirstViewController: UIViewController, ARSCNViewDelegate, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
    
    
    @IBOutlet var sceneView: ARSCNView!
    
    let material = SCNMaterial()
    var faceMask: SCNNode!
    var contentNode: SCNNode?
    var faceOverlay: SCNNode?
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        if show3DText == false {
            setLable()
        }
        
        sceneView.delegate = self
        sceneView.showsStatistics = false
        
        
    }
    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let configration = ARFaceTrackingConfiguration()
        sceneView.session.run(configration)
    }
    public override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
    }
    
    func setLable() {
        let lable = UILabel()
        lable.frame = CGRect(x: 10, y: 50, width: view.bounds.width / 3, height: view.bounds.height / 8)
        lable.backgroundColor = .lightGray
        lable.alpha = 0.7
        lable.numberOfLines = 0
        lable.adjustsFontSizeToFitWidth = true
        lable.layer.masksToBounds = true
        lable.layer.cornerRadius = 20
        lable.text = chooseFaceName.text
        self.view.addSubview(lable)
    }
    
    
    
    public func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        
        let faceGeometry = ARSCNFaceGeometry(device: sceneView.device!)
        faceMask = SCNNode(geometry: faceGeometry)
        material.diffuse.contents = (chooseFaceName.sceneName + ".png")
        faceGeometry?.materials = [material]
        
        contentNode = SCNNode()
        contentNode?.addChildNode(faceMask)
        if show3DText == true {
            
            let scene = SCNScene(named: (chooseFaceName.sceneName + ".scn"))
            faceOverlay = scene!.rootNode.childNode(withName: "text", recursively: true)
            faceOverlay?.name = "text"
            faceOverlay?.position = SCNVector3(
                x: faceMask.position.x - 0.4,
                y: faceMask.position.y + 0.1,
                z: faceMask.position.z + 0.1 )
            faceOverlay!.scale = SCNVector3(x: 0.003, y: 0.003, z: 0.0005)
            
            contentNode?.addChildNode(faceOverlay!)
        }
        return contentNode
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        guard let faceGeometry = contentNode?.childNodes.first!.geometry as? ARSCNFaceGeometry,
              let faceAnchor = anchor as? ARFaceAnchor
        else { return }
        
        faceGeometry.update(from: faceAnchor.geometry)
        
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        
    }
    public func receive(_ message: PlaygroundValue) {
        
        
    }
    
    public func faceToCamera() {
        self.sceneView.scene.rootNode.addChildNode(self.sceneView.pointOfView!)
        let lookAt = SCNLookAtConstraint(target: self.sceneView.pointOfView)
        lookAt.isGimbalLockEnabled = true
        faceOverlay?.constraints = [lookAt]
    }
    
//    func setupNode() {
//        let scene = SCNScene(named: (chooseFaceName.sceneName + ".scn"))
//        faceOverlay = scene!.rootNode.childNode(withName: "text", recursively: true)
//        faceOverlay?.name = "text"
//        faceOverlay?.position = SCNVector3(
//            x: faceMask.position.x - 0.4,
//            y: faceMask.position.y + 0.1,
//            z: faceMask.position.z + 0.1 )
//        faceOverlay!.scale = SCNVector3(x: 0.003, y: 0.003, z: 0.0005)
//
//        faceToCamera()
//    }
//
//    func setupFaceNode() {
//        let faceGeometry = ARSCNFaceGeometry(device: sceneView.device!)
//        faceMask = SCNNode(geometry: faceGeometry)
//        material.diffuse.contents = (chooseFaceName.sceneName + ".png")
//        faceGeometry?.materials = [material]
//
//    }
    
}
