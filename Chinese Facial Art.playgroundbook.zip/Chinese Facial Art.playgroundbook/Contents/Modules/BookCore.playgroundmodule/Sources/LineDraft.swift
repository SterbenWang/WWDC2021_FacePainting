//
//  LineDraft.swift
//  BookCore
//
//  Created by Sterben on 2021/4/19.
//

import Foundation

public enum LineDraft: String {
    case clear
    case white
    case black
    case style_1
//    case style_2
}

public func selectLineDraft(named: LineDraft) -> String {
    let lineDraft: String
    switch named {
    case .clear:
        lineDraft = "clear"
    case .white:
        lineDraft = "white"
    case .black:
        lineDraft = "black"
    case .style_1:
        lineDraft = "xiangao_1.png"
//    case .style_2:
//        lineDraft = "white"
    }
    return lineDraft
}
