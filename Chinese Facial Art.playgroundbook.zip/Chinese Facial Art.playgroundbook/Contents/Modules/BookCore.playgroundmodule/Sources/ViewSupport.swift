//
//  ViewSupport.swift
//  BookCore
//
//  Created by Sterben on 2021/4/12.
//


import UIKit
import PlaygroundSupport

public func instantiateLiveView0() -> PlaygroundLiveViewable {
    let storyboard = UIStoryboard(name: "View", bundle: nil)
    
    let ViewController = storyboard.instantiateViewController(withIdentifier: "LiveView0") as! LiveView0Controller
    
    return ViewController
}

public func instantiateLiveView1() -> PlaygroundLiveViewable {
    let storyboard = UIStoryboard(name: "View", bundle: nil)
    
    let ViewController = storyboard.instantiateViewController(withIdentifier: "LiveView1") as! LiveView1Controller
    
    return ViewController
}

public func instantiateLiveView2() -> PlaygroundLiveViewable {
    let storyboard = UIStoryboard(name: "View", bundle: nil)
    
    let ViewController = storyboard.instantiateViewController(withIdentifier: "LiveView2") as! LiveView2Controller
    
    return ViewController
}

public func instantiateLiveView3() -> PlaygroundLiveViewable {
    let storyboard = UIStoryboard(name: "View", bundle: nil)
    
    let ViewController = storyboard.instantiateViewController(withIdentifier: "LiveView3") as! LiveView3Controller
    
    return ViewController
}




public func instantiateFirstView() -> PlaygroundLiveViewable {
    let storyboard = UIStoryboard(name: "View", bundle: nil)
    
    let ViewController = storyboard.instantiateViewController(withIdentifier: "FirstView") as! FirstViewController
    
    return ViewController
}


public func instantiateSecondView() -> PlaygroundLiveViewable {
    let storyboard = UIStoryboard(name: "View", bundle: nil)
    
    let ViewController = storyboard.instantiateViewController(withIdentifier: "SecondView") as! SecondViewController
    
    return ViewController
}


public func instantiateThirdView() -> PlaygroundLiveViewable {
    let storyboard = UIStoryboard(name: "View", bundle: nil)
    
    let ViewController = storyboard.instantiateViewController(withIdentifier: "ThirdView") as! ThirdViewController
    
    return ViewController
}

public func instantiateFourthView() -> PlaygroundLiveViewable {
    let storyboard = UIStoryboard(name: "View", bundle: nil)
    
    let ViewController = storyboard.instantiateViewController(withIdentifier: "FourthView") as! FourthViewController
    
    return ViewController
}
