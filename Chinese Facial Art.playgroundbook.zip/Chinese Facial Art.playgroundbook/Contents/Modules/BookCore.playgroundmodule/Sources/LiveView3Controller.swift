//
//  LiveView3Controller.swift
//  BookCore
//
//  Created by Sterben on 2021/4/18.
//
import UIKit
import PlaygroundSupport
import ARKit
import SceneKit


@objc(BookCore_LiveView3Controller)

public class LiveView3Controller: UIViewController, ARSCNViewDelegate, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
    
    var image = UIImageView()
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    public func receive(_ message: PlaygroundValue) {
        
        
    }
    
    
}
