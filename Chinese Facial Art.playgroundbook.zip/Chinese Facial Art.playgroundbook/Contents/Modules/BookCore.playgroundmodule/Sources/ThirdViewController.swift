//
//  ThirdViewController.swift
//  BookCore
//
//  Created by Sterben on 2021/4/12.
//

import UIKit
import PencilKit
import SceneKit
import ARKit
import PlaygroundSupport
import PhotosUI

public var chooseLineDraft = selectLineDraft(named: .style_1)
public var userUpImage: UIImage = #imageLiteral(resourceName: "yellow.png")
public var allowUserUpdate: Bool = false

@objc(BookCore_ThirdViewController)
class ThirdViewController: UIViewController, PKToolPickerObserver, PKCanvasViewDelegate, ARSCNViewDelegate, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
    
    var canvasView = PKCanvasView()
    var imageView = UIImageView()
    var sceneView = ARSCNView()
    let btn = UIButton()
    
    var drawing = PKDrawing()
    var toolPicker: PKToolPicker!
    let material = SCNMaterial()
    var image = UIImage()
    var nowLineDraft: String = chooseLineDraft
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        makeupTimer()
        setupNeedView()
        
        //创建前置配置
        let configration = ARFaceTrackingConfiguration()
        sceneView.session.run(configration)
        sceneView.delegate = self
        sceneView.showsStatistics = false
        canvasView.delegate = self
        canvasView.drawing = drawing
        
        if #available(iOSApplicationExtension 14.0, *) {
            toolPicker = PKToolPicker()
        }else{
            
        }
        
        canvasView.drawingGestureRecognizer.isEnabled = true
        toolPicker.setVisible(true, forFirstResponder: canvasView)
        toolPicker.addObserver(self)
        toolPicker.addObserver(canvasView)
        canvasView.becomeFirstResponder()
        
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        sceneView.session.pause()
    }
    
    func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        let facegeomerty = ARSCNFaceGeometry(device: sceneView.device!)
        let node = SCNNode(geometry: facegeomerty)
        
        node.geometry?.firstMaterial?.fillMode = .lines
        
        material.diffuse.contents = image
        facegeomerty?.materials = [material]
        
        return node
        
    }
    
    func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        guard let faceGeometry = node.geometry as? ARSCNFaceGeometry,
              let faceAnchor = anchor as? ARFaceAnchor
        else { return }
        faceGeometry.update(from: faceAnchor.geometry)
        
    }
    
    func setupNeedView() {
        
        let viewBounds = self.view.bounds
        //创建image View并添加
        if allowUserUpdate == false {
            if nowLineDraft == "clear" {
                
            }else{
                imageView.frame = CGRect(x: viewBounds.width / 2, y: 0, width: viewBounds.width / 2, height: viewBounds.height)
                var backGroundImage = UIImage()
                if nowLineDraft == "white" {
                    imageView.backgroundColor = .white
                }else if nowLineDraft == "black" {
                    imageView.backgroundColor = .black
                }else {
                    backGroundImage = UIImage(named:chooseLineDraft)!
                    imageView.image = backGroundImage
                    imageView.contentMode = .scaleAspectFill
                }
                self.view.addSubview(imageView)
            }
        }else{
            imageView.frame = CGRect(x: viewBounds.width / 2, y: 0, width: viewBounds.width / 2, height: viewBounds.height)
            imageView.image = userUpImage
            imageView.contentMode = .scaleAspectFill
            self.view.addSubview(imageView)
        }
        
        //创建canvas View并添加
        canvasView.frame = CGRect(x: viewBounds.width / 2, y: 0, width: viewBounds.width / 2, height: viewBounds.height)
        canvasView.backgroundColor = .clear
        self.view.addSubview(canvasView)
        
        //创建scene View并添加
        sceneView.frame = CGRect(x: 0, y: 0, width: viewBounds.width / 2, height: viewBounds.height)
        let scene = SCNScene()
        sceneView.scene = scene
        self.view.addSubview(sceneView)
        
        btn.frame = CGRect(x: viewBounds.width - 70, y: viewBounds.height - 50, width: 60, height: 40)
        btn.backgroundColor = .link
        btn.setTitle("Save", for: .normal)
        self.view.addSubview(btn)
        btn.addTarget(self, action: #selector(savePicture), for: .touchUpInside)
        
    }
    
    func updatePicture() {
        let upImage = canvasView.drawing.image(from: CGRect(x: 0, y: 0, width: canvasView.frame.width, height: canvasView.frame.height), scale: 1)
        
        
        DispatchQueue.main.async { [self] in
            material.diffuse.contents = upImage
        }
    }
    
    @objc func savePicture() {
        UIGraphicsBeginImageContextWithOptions(canvasView.bounds.size, false, UIScreen.main.scale)
        canvasView.drawHierarchy(in: canvasView.bounds, afterScreenUpdates: true)
        
        let saveImage = UIGraphicsGetImageFromCurrentImageContext()
        
        UIGraphicsEndImageContext()
        
        if saveImage != nil {
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAsset(from: saveImage!)
            }, completionHandler: {
                success, error in
            })
        }
    }
    
    func makeupTimer() {
        let timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true, block: { _ in self.updatePicture() })
        RunLoop.main.add(timer, forMode: .default)
    }
}
