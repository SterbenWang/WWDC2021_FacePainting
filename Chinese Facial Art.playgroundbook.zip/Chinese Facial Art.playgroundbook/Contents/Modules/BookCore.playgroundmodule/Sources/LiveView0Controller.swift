//
//  MainViewController.swift
//  BookCore
//
//  Created by Sterben on 2021/4/12.
//

import UIKit
import PlaygroundSupport
import ARKit
import SceneKit


@objc(BookCore_LiveView0Controller)

public class LiveView0Controller: UIViewController, ARSCNViewDelegate, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
    
    var image = UIImageView()
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    public func receive(_ message: PlaygroundValue) {
        
        
    }
    
    
}



