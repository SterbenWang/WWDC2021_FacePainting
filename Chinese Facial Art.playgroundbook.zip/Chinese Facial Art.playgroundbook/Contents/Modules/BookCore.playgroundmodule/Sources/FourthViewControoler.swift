//
//  FourthViewControoler.swift
//  BookCore
//
//  Created by Sterben on 2021/4/19.
//
import UIKit
import PlaygroundSupport
import SceneKit
import ARKit
import PhotosUI

public var userUploadImage: UIImage = #imageLiteral(resourceName: "blue.png")

public var userUpBackgroundImage: UIImage = #imageLiteral(resourceName: "background_1.png")

public var allowUserUploadImage: Bool = false

public var faceNumber: Int = 1

@objc(BookCore_FourthViewController)

public class FourthViewController: UIViewController, ARSCNViewDelegate, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
    
    @IBOutlet var sceneView: ARSCNView!
    
    @IBAction func takephoto(_ sender: Any) {
        UIGraphicsBeginImageContextWithOptions(view.bounds.size, false, UIScreen.main.scale)
        sceneView.drawHierarchy(in: sceneView.bounds, afterScreenUpdates: true)
        
        let saveImage = UIGraphicsGetImageFromCurrentImageContext()
        
        UIGraphicsEndImageContext()
        
        if saveImage != nil {
            PHPhotoLibrary.shared().performChanges({
                PHAssetChangeRequest.creationRequestForAsset(from: saveImage!)
            }, completionHandler: {
                success, error in
            })
        }
    }
    @IBOutlet var btn: UIButton!
    
    let material = SCNMaterial()
    var faceMask: SCNNode!
    var contentNode: SCNNode?
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        btn.layer.masksToBounds = false
        btn.layer.cornerRadius = 90.0
        
        sceneView.delegate = self
        sceneView.showsStatistics = false
    }
    
    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let configration = ARFaceTrackingConfiguration()
        configration.maximumNumberOfTrackedFaces = faceNumber
        sceneView.session.run(configration)
    }
    
    public override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        sceneView.session.pause()
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        let facegeometry = ARSCNFaceGeometry(device: sceneView.device!)
        let node = SCNNode(geometry: facegeometry)
        
        if allowUserUploadImage == false {
            material.diffuse.contents = (chooseFaceName.sceneName + ".png")
            facegeometry?.materials = [material]
        }else{
            material.diffuse.contents = userUploadImage
            facegeometry?.materials = [material]
        }
        
        return node
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        guard let facegeometry = node.geometry as? ARSCNFaceGeometry,
              let faceAnchor = anchor as? ARFaceAnchor
        else { return }
        facegeometry.update(from: faceAnchor.geometry)
    }
    
    
    
    public func receive(_ message: PlaygroundValue) {
        
        
    }
}
