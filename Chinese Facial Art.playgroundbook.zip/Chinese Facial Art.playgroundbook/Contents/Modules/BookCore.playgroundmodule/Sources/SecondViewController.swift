//
//  SecondViewController.swift
//  BookCore
//
//  Created by Sterben on 2021/4/12.
//

import UIKit
import PlaygroundSupport
import ARKit
import SceneKit
import AVFoundation


public var randomApper: Bool?


@objc(BookCore_SecondViewController)
public class SecondViewController: UIViewController, ARSCNViewDelegate, PlaygroundLiveViewMessageHandler, PlaygroundLiveViewSafeAreaContainer {
    
    @IBOutlet var sceneView: ARSCNView!
    var audioPlayer: SCNAudioPlayer!
    let material = SCNMaterial()
    var faceMask: SCNNode!
    var contentNode: SCNNode?
    var masks = ["red.png", "blue.png", "yellow.png", "white.png", "black.png"]
    var maskChanged: Bool = true
    var num: Int = 0
    let musicManager = MusicManager()
    var music: Music = .shua
    
    
    public override func viewDidLoad() {
        super.viewDidLoad()
        
        sceneView.delegate = self
        sceneView.showsStatistics = false
        
        guard ARFaceTrackingConfiguration.isSupported else {
            fatalError("Face tracking is not supported on this device")
        }
    }
    
    func playMusic(node: SCNNode) {
        let musicUrl = Bundle.main.url(forResource: "shua", withExtension: "mp3")!
        let music = SCNAudioSource(url: musicUrl)!
        audioPlayer = SCNAudioPlayer(source: music)
        node.addAudioPlayer(audioPlayer)
        let play = SCNAction.playAudio(music, waitForCompletion: false)
        node.runAction(play)
    }
    
    public override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        let configration = ARFaceTrackingConfiguration()
        
        sceneView.session.run(configration)
        
        
    }
    
    public override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        // Pause the view's session
        sceneView.session.pause()
    }
    
    public func receive(_ message: PlaygroundValue) {
        
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, nodeFor anchor: ARAnchor) -> SCNNode? {
        let faceGeometry = ARSCNFaceGeometry(device: sceneView.device!)
        let node = SCNNode(geometry: faceGeometry)
        node.name = "face"
        node.geometry?.firstMaterial?.fillMode = .lines
        
        material.diffuse.contents = masks[0]
        faceGeometry?.materials = [material]
        
        return node
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, didUpdate node: SCNNode, for anchor: ARAnchor) {
        
        guard let faceGeometry = node.geometry as? ARSCNFaceGeometry,
              let faceAnchor = anchor as? ARFaceAnchor
        else { return }
        
        faceGeometry.update(from: faceAnchor.geometry)
        
        
        
    }
    
    public func renderer(_ renderer: SCNSceneRenderer, updateAtTime time: TimeInterval) {
        for n in sceneView.scene.rootNode.childNodes {
            if n.name == "face" {
                
                if n.isHidden == true && maskChanged == true{
                    
                    if randomApper == true {
                        let temp = Int(arc4random()) % masks.count
                        if temp != num {
                            num = temp
                        }else if temp == 0 {
                            num = 1
                        }else{
                            num = masks.count - 2
                        }
                    }else{
                        if num < masks.count - 1 {
                            num += 1
                        }else{
                            num = 0
                        }
                    }
                    musicManager.play(music: music, loop: 1, volumeSize: 0.7)
                    material.diffuse.contents = masks[num]
                    maskChanged = false
                }
                
                if n.isHidden == false {
                    maskChanged = true
                }
            }
        }
    }
    
}
