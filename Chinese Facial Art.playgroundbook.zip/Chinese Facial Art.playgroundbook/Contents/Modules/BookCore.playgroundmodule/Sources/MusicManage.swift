//
//  MusicManage.swift
//  BookCore
//
//  Created by Sterben on 2021/4/18.
//

import AVFoundation

public enum Music: String {
    case shua = "shua"
}

public class MusicManager {
    var audioPlayer: AVAudioPlayer!
    
    init() {
        audioPlayer = AVAudioPlayer()
    }

    func play(music: Music, loop: Int, volumeSize: Float) {
        //获得音频会话对象,该对象属于单例模式,也就是说不用开发者而自行实例化.这个类在各种音频环境中,起着重要作用
        let session = AVAudioSession.sharedInstance()
        //在音频播放前,首先创建一个异常捕捉语句
        do {
            //启动音频会话管理,此时会阻断后台音乐的播放.
            try session.setActive(true)
            //设置音频操作类别,表示该应用仅支持音频的播放.
            try session.setCategory(AVAudioSession.Category.playback)
            //设置应用程序支持接受远程控制事件，playgroundbook不支持远程这个功能
            //            UIApplication.shared.beginReceivingRemoteControlEvents()
            //定义字符串变量,描述声音文件路径
            let path = Bundle.main.path(forResource: music.rawValue, ofType: "mp3")
            //将字符串路径,转换为网址路径
            let soundUrl = NSURL(fileURLWithPath: path!)
            //对音频播放对象,进行初始化,并加载制定的音频文件
            try audioPlayer = AVAudioPlayer(contentsOf: soundUrl as URL)
            //为音频播放做好准备
            audioPlayer.prepareToPlay()
            //设置音频播放对象播放音量的大小
            audioPlayer.volume = volumeSize
            //播放次数
            audioPlayer.numberOfLoops = loop //-1:无限循环播放
            audioPlayer.play()
        } catch {
            print(error)
        }
    }
}
