//
//  File.swift
//  BookCore
//
//  Created by Sterben on 2021/4/16.
//

import UIKit
import BookCore
import PlaygroundSupport

PlaygroundPage.current.liveView = instantiateLiveView2()

