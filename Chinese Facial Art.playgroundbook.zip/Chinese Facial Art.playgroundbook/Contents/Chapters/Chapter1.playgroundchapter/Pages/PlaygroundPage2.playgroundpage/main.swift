//#-hidden-code
import UIKit
import BookCore
import PlaygroundSupport


//#-end-hidden-code

/*:
 # **Let's try to draw Facebook**
 
 Now, the third level, the one I'm most proud of, where you can create your own face and render it or save it. ✌🏼
 ## ⚠️**Warning**⚠️
 * ## **Please use full screen to experience**
 
 ### 🌟Notice：
 * 1⃣️ You can select the default template to draw your own face.
 * 2⃣️ You can upload your favorite template to draw, and finally get the effect you want.😀
 
 I hope you can enjoy this level, because I really put a lot of effort into it to make it run smoothly.😅
 
 #### I played ✋
 ![I played](iplayed_1.PNG "I played")
 
 */

//:### Choose the LineDraft you want
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, clear, white, black, style_1, style_2)
chooseLineDraft = selectLineDraft(named: ./*#-editable-code*/style_1/*#-end-editable-code*/)

//: If you want to use your own template, please **change this bool value** and **upload an image**
//#-code-completion(identifier, show, true, false)
allowUserUpdate = /*#-editable-code*/false/*#-end-editable-code*/

//: Change the Picture to upload you own picture
//Input code to upload your Facial Mask line draft
//#-code-completion(identifier, show, userUpImage, =, #imageLiteral(), .)
//#-editable-code
userUpImage = #imageLiteral(resourceName: "yellow.png")
//#-end-editable-code

//#-hidden-code
PlaygroundPage.current.liveView = instantiateThirdView()
//#-end-hidden-code
