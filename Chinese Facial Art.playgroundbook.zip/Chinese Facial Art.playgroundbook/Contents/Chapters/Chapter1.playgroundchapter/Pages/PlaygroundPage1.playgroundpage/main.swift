//#-hidden-code
import UIKit
import BookCore
import PlaygroundSupport
//#-end-hidden-code

/*:
 # **The art of mask changing in Sichuan Opera**
 
 Congratulations on having successfully passed the first level！🎉 Next is the second level.
 
 ### 🌟Notice：
 * 1⃣️ You can change your current facial mask by constantly waving your hand👋 or blocking your face🤦🏼‍♀️.
 
 * 2⃣️ If you want your face to appear in a random way, you can set the following bool from false to true.
 
 
 At this level I hope you can experience the real Sichuan Opera face-changing💗.
 */
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, false, true)

//:#### Try to use random to change face
randomApper = /*#-editable-code*/false/*#-end-editable-code*/
/*:
 If you don’t make this content true, it will appear in an orderly form
 just like: red -> blue -> yellow -> white -> black -> red -> ...
*/
//#-hidden-code
PlaygroundPage.current.liveView = instantiateSecondView()
//#-end-hidden-code

