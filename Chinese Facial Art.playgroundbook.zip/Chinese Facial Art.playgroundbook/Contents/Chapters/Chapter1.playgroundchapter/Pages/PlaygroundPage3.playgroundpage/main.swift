//#-hidden-code
import UIKit
import BookCore
import PlaygroundSupport

PlaygroundPage.current.liveView = instantiateFourthView()

//#-end-hidden-code

/*:
 # **Take a photo with your FaceMask**
 
 ## Congratulations,
 you have come to the last level, in this level you can upload the face you just drawn and take a photo with it.
 
 I hope you will want the Swift Playground Book I made this time. I really made it very hard, because I wanted to promote Chinese traditional drama so that more people could understand it and like it. You know that sitting in a theater or teahouse in China, drinking tea and watching drama is a very enjoyable thing. I hope you can also experience this sense of happiness. This is the purpose of making this Swift Playground Book.
 
 ### 🌟Notice
 * 1⃣️ You need to upload **your favorite Facebook** or **use the default Facebook**
 * 2⃣️ If you want, you can also **upload the background you want** to take a group photo
 
 */

//:### Choose the number of faces to track🔢 The max is 4, Please don't exceed
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, 1, 2, 3, 4)
faceNumber = /*#-editable-code*/1/*#-end-editable-code*/

//:### Choose the facial mask you like👀
//#-code-completion(identifier, show, red, blue, white, black, yellow, .)
chooseFaceName = chooseFace(named: ./*#-editable-code*/red/*#-end-editable-code*/)

//:### Upload your facial mask and use it
//allowUserUpFaceImage
//#-code-completion(identifier, show, false, true)
allowUserUploadImage = /*#-editable-code*/false/*#-end-editable-code*/
//Input code to upload your Facial Mask
//#-code-completion(identifier, show, userUploadImage, =)
//#-editable-code
userUploadImage = #imageLiteral(resourceName: "blue.png")
//#-end-editable-code

//#-hidden-code

//userUpBackgroundImage
userUpBackgroundImage = #imageLiteral(resourceName: "background_1.png")

PlaygroundPage.current.liveView = instantiateFourthView()

//#-end-hidden-code
