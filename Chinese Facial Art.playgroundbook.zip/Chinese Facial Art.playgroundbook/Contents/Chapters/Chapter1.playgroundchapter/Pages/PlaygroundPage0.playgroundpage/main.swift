//#-hidden-code
import UIKit
import PlaygroundSupport
import BookCore

//#-end-hidden-code

/*:
 # **Introduce Chinese Facial Mask**
 
 Hello everyone! I'm **Yaoyuan Wang**, a college student in China🇨🇳.
 
 I use ARKit and Pencil to created an amazing Playground Book about **Chinese Facial Art** for **WWDC 2021 Swift Student Challenge submission** 😊
 
 ## **let's try to understand the different meanings of facial masks！** #
 
 ### 🌟Notice：
 * By clicking on the different words on the left, you can learn about the different meanings of facial masks.
 */

//:### Choose the color you like 👀
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, red, blue, white, black, yellow, .)
chooseFaceName = chooseFace(named: ./*#-editable-code*/red/*#-end-editable-code*/)

//:### Display 3D text 🗒 （**Full screen** viewing is recommended）
//#-code-completion(everything, hide)
//#-code-completion(identifier, show, false, true)
show3DText = /*#-editable-code*/true/*#-end-editable-code*/

//#-hidden-code
PlaygroundPage.current.liveView = instantiateFirstView()
//#-end-hidden-code
